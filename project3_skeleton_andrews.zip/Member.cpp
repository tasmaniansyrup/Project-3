#include "Member.h"

Member::Member()
{
    fullness_ = 50;
    name_ = "";
    armor_ = false;
}
Member::Member(string name)
{
    fullness_ = 50;
    name_ = name;
    armor_ = false;
}

int Member::getFullness()
{
    return fullness_;
}

void Member::setFullness(int fullness)
{
    fullness_ = fullness;
}

string Member::getName()
{
    return name_;
}

void Member::setName(string name)
{
    name_ = name;
}

bool Member::getArmor()
{
    return armor_;
}

void Member::setArmor(bool armor)
{
    armor_ = armor;
}

void Member::removeWeapon()
{
    weapon_.setName("");
    weapon_.setCost(-1);
    weapon_.setUpgradeLevel(-1);
}

void Member::removeArmor()
{
    armor_ = false;
}