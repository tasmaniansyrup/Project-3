#ifndef PLAYER_H
#define MEMBERS_H

#include "Weapons.h"

class Member
{
private:
    int fullness_;
    string name_;
    bool armor_;
    Weapon weapon_;

public:
    Member();
    Member(string name);

    int getFullness();
    void setFullness(int fullness);

    string getName();
    void setName(string name);

    bool getArmor();
    void setArmor(bool armor);

    void removeWeapon();

    void removeArmor();
};

#endif