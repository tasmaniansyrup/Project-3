#include <iostream>
#include <vector>
#include "Party.h"

using namespace std;

int main()
{
    Party Group_;
    Cookware Pan = Cookware("Pan", 999, 0);
    
    vector<Cookware> Wares_;
    cout << Group_.getGold() << endl;
    Group_.addGold(50);
    cout << Group_.getGold() << endl;

    Group_.addKeys(2);
    cout << Group_.getKeys() << endl;

    Group_.addRoomsCleared(2);
    cout << Group_.getRoomsCleared() << endl;

    Group_.addCookware(Pan);
    
    Wares_ = Group_.getCookware();
    for(int i = 0; i < Wares_.size(); i++)
    {
        cout << Wares_.at(i).getName() << endl;
    }

    Group_.addTreasureAt(3);
    cout << Group_.getTreasure()[3] << endl;

}