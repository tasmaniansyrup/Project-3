#include <iostream>
#include "Party.h"

using namespace std;

Party::Party()
{
    gold_ = 100;
    keys_ = 0;
    ingredients_ = 0;
    rooms_cleared_ = 0;
    turns_ = 0;
    
    for(int i = 0; i < 5; i++)
    {
        treasure[i] = 0;
    }
}

int Party::getGold()
{
    return gold_;
}

void Party::setGold(int gold)
{
    gold_ = gold;
}

void Party::addGold(int gold)
{
    gold_ += gold;
}


int Party::getKeys()
{
    return keys_;
}

void Party::setKeys(int keys)
{
    keys_ = keys;
}

void Party::addKeys(int keys)
{
    keys_ += keys;
}


int Party::getIngredients()
{
    return ingredients_;
}
void Party::setIngredients(int ingredients)
{
    ingredients_ = ingredients;
}
void Party::addIngredients(int ingredients)
{
    ingredients_ += ingredients;
}


int Party::getRoomsCleared()
{
    return rooms_cleared_;
}

void Party::setRoomsCleared(int rooms_cleared)
{
    rooms_cleared_ = rooms_cleared;
}

void Party::addRoomsCleared(int rooms_cleared)
{
    rooms_cleared_ += rooms_cleared;
}

vector<Cookware> Party::getCookware()
{
    return cookware;
}

Cookware Party::useCookwareAt(int index)
{
    return cookware.at(index);
}

void Party::addCookware(Cookware cookware_)
{
    cookware.push_back(cookware_);
}

void Party::removeCookware(int index)
{
    cookware.erase(cookware.begin() + index);
}


int * Party::getTreasure()
{
    return treasure;
}

void Party::sellTreasureType(char type)
{
    // Switch statement that removes the tresure thats sold from the array of treasure and then increments the variable gold accordingly.
}
void Party::sellAllTreasure()
{
    // Removes all treasure from the array and then increments the variable gold accordingly
}
void Party::addTreasureAt(int index)
{
    treasure[index]++;
}

bool Party::fightMonster()
{
    // Use equation given to calculate whether or not the party can defeat the boss.
    return 1;
}

int Party::getMisfortune()//1, 2, 3, or 4 as specified in write up
{
    // Have a 40 percent chance of a list of misfortunes falling upon the party and its members.
    return 1;
}

void Party::removePartyMember(int index)
{
    party_members.erase(party_members.begin() + index);
}

bool Party::doorPuzzle()
{
    // Basically make rock, paper, scizzors and implement it.
    return 1;
}
bool Party::npcPuzzle(string answer)
{
    // Prompt the user with a riddle by reading from a file with said riddle and answer in it. Check their answer.
    return 1;
}

int Party::investigate()
{
    // Investigates a space that has not yet been explored and has a chance of certain events taking place that will be implemented.
    return 1;
}